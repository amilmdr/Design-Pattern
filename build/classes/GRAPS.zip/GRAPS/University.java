/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GRAPS;

/**
 *
 * @author Amil
 */
public class University {
    private int universityId;
    private  String universityName;
    public static void main(String [] args){
        University Uv=new University();
        
    }
}
